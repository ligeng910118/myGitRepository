<?php

namespace Addons\WeiPicture\Model;
use Think\Model;

/**
 * WeiPicture模型
 */
class WeiPictureModel extends Model{

}
