<?php

namespace Addons\Cms\Controller;

use Think\ManageBaseController;

class CmsController extends ManageBaseController {
}
