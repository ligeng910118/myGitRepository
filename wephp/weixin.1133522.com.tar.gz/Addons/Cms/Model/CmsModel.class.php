<?php

namespace Addons\Cms\Model;
use Think\Model;

/**
 * Cms模型
 */
class CmsModel extends Model{

}
