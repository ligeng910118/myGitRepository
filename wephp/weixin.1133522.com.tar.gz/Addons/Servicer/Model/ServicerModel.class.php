<?php

namespace Addons\Servicer\Model;
use Think\Model;

/**
 * Servicer模型
 */
class ServicerModel extends Model{
	
}
