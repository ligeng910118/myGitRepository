<?php

namespace Addons\WeiSite\Controller;
use Addons\WeiSite\Controller\BaseController;

class LeafletsController extends BaseController{
	//首页
	function index(){
		$this->display();
	}
	//分类列表
	function category(){
		$this->display();
	}
	//相册模式
	function picList(){
		$this->display();
	}
	//详情
	function detail(){
		$this->display();
	}
}
