<?php
return array (
		'title' => '图文列表V-1(无banner)',
		'author' => 'jacy',
		'desc' => '',
        'has_slide' => 0
);					