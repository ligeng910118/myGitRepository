<?php
return array (
		'title' => '图文列表V-1',
		'author' => 'jacy',
		'desc' => '',
        'has_slide' => 1
);					