<?php
return array (
		'title' => '图片作为分类格子',
		'author' => 'jacy',
		'desc' => 'banner图片规格是640x300 分类图标是60x60或以上规格正方形图片'
);					