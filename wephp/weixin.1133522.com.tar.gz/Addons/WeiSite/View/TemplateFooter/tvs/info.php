<?php
return array (
		'title' => 'tvs通用菜单',
		'author' => 'jacy',
		'desc' => '无菜单'
);					